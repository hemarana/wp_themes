<?php get_header(); ?>
<div class="container">
  <?php get_template_part('templates-part/home', 'feaure') ?>
  <h1>Above this templates</h1>
</div>

<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4">
      <?php get_sidebar('sidebar-1'); ?>
    </div>
    <div class="col-sm-8">
      <?php
      $post_fetch = array(
        'cat' => 1  // Ensure the category ID is correct
      );
      $post_query = new WP_Query($post_fetch);

      if ($post_query->have_posts()): ?>
        <?php while ($post_query->have_posts()):
          $post_query->the_post(); ?>
          <div class="post-content">
            <a href="<?php echo get_the_permalink(get_the_ID()) ?>"> <?php the_title(); ?>
              <?php the_post_thumbnail(
                'full',
                array(
                  'class' => 'post-img-theme',
                  'style' => 'width: 100px; height:100px;'
                )
              ); ?></a>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No posts found</p>
      <?php endif; ?>



      <?php if (have_posts()): ?>
        <?php while (have_posts()):
          the_post(); ?>
          <?php the_content(); ?>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No posts found.</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="container">
<?php
      $post_fetch = array(
        'post_type' => 'product' , // dashboard post click select id
        'posts_per_page' => 3,
        'order' => 'DESC'

      );
      $post_query = new WP_Query($post_fetch);

      if ($post_query->have_posts()): ?>
        <?php while ($post_query->have_posts()):
          $post_query->the_post(); ?>
          <div class="post-content">
            <a href="<?php echo get_the_permalink(get_the_ID()) ?>"> <?php the_title(); ?>
              <?php the_post_thumbnail(
                'full',
                array(
                  'class' => 'post-img-theme',
                  'style' => 'width: 100px; height:100px;'
                )
              ); ?></a>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p>No posts found</p>
      <?php endif; ?>
</div>
<?php get_footer() ?>