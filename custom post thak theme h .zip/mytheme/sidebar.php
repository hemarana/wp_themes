<div id="sidebar-primary" class="sidebar">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</div>